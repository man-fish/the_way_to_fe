describe('demo', function () {

  it('should do what...', function () {
    expect(0).not.toBe(1);
  });

});