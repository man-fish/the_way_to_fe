exports.version = '{version}';
exports.Parser = require('../common/parser');