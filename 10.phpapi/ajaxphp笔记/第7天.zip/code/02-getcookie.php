<?php

// 专门取 cookie
// 关联数组的方式访问客户端提交过来的 Cookie
var_dump($_COOKIE);


